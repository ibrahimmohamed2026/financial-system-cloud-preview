import { esc, toast, errText } from "../ui.js";

export async function render(main, { api }) {
  const tr = (ar, en) => { try { return localStorage.getItem("fs_lang") === "en" ? en : ar; } catch { return ar; } };
  main.innerHTML = `<section class="sec">
    <h3>${tr("إعادة ضبط بيانات النظام","System Data Reset")}</h3>
    <div class="panel" style="padding:16px">
      <div class="tag no">${tr("إجراء حساس — لا يتم الحذف قبل المعاينة والتأكيد","Sensitive action — nothing is deleted before preview and confirmation")}</div>
      <p>${tr("ستظهر لك الجداول وعدد السجلات التي سيتم تصفيرها قبل أي تنفيذ.","Review the table-by-table counts before executing the complete reset.")}</p>
      <div style="margin-top:16px">
        <h4>${tr("التصفير الشامل","Complete reset")}</h4>
        <p class="muted">${tr("يمسح جميع الحركات والقيود والمستندات والأطراف والأصناف والمخازن، ويصفّر كل الأرصدة الافتتاحية. ميزان المراجعة وأرصدة الخزائن ستصبح صفرًا. يحتفظ بالمستخدمين والصلاحيات والوظائف ودليل الحسابات والشركة والسنة المالية والمشروعات وتعريفات الخزائن وربطها وأسعار الصرف وقوالب الشيكات وسجل المراجعة. لا يحذف قاعدة البيانات أو هيكلها.","Deletes all transactions, journal entries, documents, parties, items and warehouses, and zeros all opening balances. Trial balance and treasury balances will be zero. Preserves users, permissions, job profiles, chart of accounts, company, fiscal year, projects, treasury definitions and GL links, exchange rates, cheque templates and audit history. The database and schema are not deleted.")}</p>
        <button class="btn danger reset-preview" data-mode="full">${tr("معاينة التصفير الشامل","Preview complete reset")}</button>
      </div>
      <div id="previewbox" style="margin-top:16px"></div>
      <div id="confirmbox" hidden style="margin-top:16px;border-top:1px solid var(--line);padding-top:16px">
        <h4>${tr("التأكيد النهائي","Final confirmation")}</h4>
        <p class="muted">${tr("سيتم إنشاء نسخة احتياطية للطوارئ أولًا، ثم حذف البيانات الموضحة في المعاينة من قاعدة التشغيل. النسخة لا تُستعاد تلقائيًا.","An emergency backup is created first, then the previewed data is cleared from the live database. The backup is not restored automatically.")}</p>
        <div class="formgrid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;align-items:end">
          <div style="display:grid;gap:8px;min-width:0">
            <label for="resetpassword" style="display:block;font-weight:600">${tr("كلمة مرور المدير","Administrator password")}</label>
            <input id="resetpassword" name="resetpassword" type="password" autocomplete="current-password" placeholder="${tr("أدخل كلمة المرور","Enter password")}" style="display:block;width:100%;box-sizing:border-box">
          </div>
          <div style="display:grid;gap:8px;min-width:0">
            <label for="resetphrase" style="display:block;font-weight:600">${tr("تأكيد التنفيذ","Execution confirmation")}</label>
            <input id="resetphrase" name="resetphrase" type="text" dir="ltr" autocomplete="off" spellcheck="false" placeholder="RESET" aria-label="Type RESET exactly" style="display:block;width:100%;box-sizing:border-box">
            <small class="muted">${tr("اكتب RESET بالحروف الإنجليزية الكبيرة","Type RESET in uppercase English letters")}</small>
          </div>
        </div>
        <button class="btn danger" id="execute" type="button" style="margin-top:16px">${tr("تنفيذ إعادة الضبط الآن","Execute reset now")}</button>
      </div>
      <div id="reseterr" class="err" style="margin-top:12px"></div>
    </div>
  </section>`;
  const $ = s => main.querySelector(s);
  let previewMode = null;
  const busy = v => main.querySelectorAll("button,input").forEach(x => x.disabled = v);
  main.querySelectorAll(".reset-preview").forEach(button => button.addEventListener("click", async () => {
    const m = button.dataset.mode;
    previewMode = null; $("#previewbox").innerHTML = "";
    busy(true); $("#reseterr").textContent = ""; $("#confirmbox").hidden = true;
    try {
      const d = await api("/admin/reset/preview?mode=" + encodeURIComponent(m));
      previewMode = m;
      const labels = {
        JournalEntryDetails:"تفاصيل قيود اليومية", JournalEntries:"قيود اليومية",
        TreasuryTransactions:"حركات الخزائن", BankReconciliations:"التسويات البنكية",
        BankReconciliationLines:"تفاصيل التسويات", Checks:"الشيكات", FinancialChecks:"الشيكات المالية",
        CheckStatusHistory:"سجل حالات الشيكات", ContractRequests:"طلبات العقود", Contracts:"العقود",
        ContractSettlementSchedules:"جدول المستخلصات", ContractAddendums:"ملاحق العقود",
        ContractAddendumLines:"بنود ملاحق العقود", ProgressBillings:"مستخلصات الأعمال",
        ContractItems:"بنود العقود", ContractDeductionRules:"قواعد الخصومات",
        ContractAccountingConfig:"إعدادات محاسبة العقود", ContractSettlements:"المستخلصات",
        ContractSettlementItems:"بنود المستخلصات", ContractChangeOrders:"أوامر التغيير",
        InventoryMovements:"حركات المخزون", SiteIssueRequests:"طلبات صرف الموقع",
        SiteIssueRequestLines:"بنود طلبات الصرف", InventoryStocktakes:"الجرد",
        InventoryStocktakeLines:"بنود الجرد", InventoryReturns:"مرتجعات المخزون",
        InventoryReturnLines:"بنود المرتجعات", PurchaseRequisitions:"طلبات الشراء",
        PurchaseRequisitionLines:"بنود طلبات الشراء", SupplierQuotations:"عروض أسعار الموردين",
        SupplierQuotationLines:"بنود عروض الأسعار", PurchaseOrders:"أوامر الشراء",
        PurchaseOrderLines:"بنود أوامر الشراء", PurchaseGoodsReceipts:"استلام التوريدات",
        PurchaseGoodsReceiptLines:"بنود الاستلام", SupplierInvoices:"فواتير الموردين",
        SupplierInvoiceLines:"بنود فواتير الموردين", ContractAttachments:"مرفقات العقود",
        TechnicalSettlementEstimates:"تقديرات المستخلصات الفنية",
        TechnicalSettlementEstimateItems:"بنود التقديرات الفنية",
        CounterpartyAliases:"الأسماء البديلة للأطراف", Counterparties:"العملاء والموردون والمقاولون",
        Beneficiaries:"المستفيدون", InventoryWarehouses:"المخازن", InventoryItems:"أصناف المخزون",
        TreasuryAccounts:"تعريفات الخزائن والبنوك", ItemCatalog:"دليل الأصناف"
      };
      $("#previewbox").innerHTML = `<h4>${tr("ملخص المعاينة","Preview summary")}</h4>
        <p><b>${tr("عدد السجلات التي ستُحذف:","Rows to delete:")} ${d.total_rows.toLocaleString()}</b></p>
        ${d.tables.length ? `<div class="tbl-wrap"><table><thead><tr><th>${tr("الجدول","Table")}</th><th>${tr("عدد السجلات","Rows")}</th></tr></thead><tbody>${d.tables.map(x=>`<tr><td>${esc(labels[x.table] || x.table)}</td><td>${x.count.toLocaleString()}</td></tr>`).join("")}</tbody></table></div>` : `<p class="muted">${tr("لا توجد سجلات في الجداول المحددة للحذف.","No records found in the selected tables.")}</p>`}
        <p>${tr("حسابات سيتم تصفير أرصدتها الافتتاحية:","Accounts with opening balances to zero:")} <b>${d.accounts_opening_balances_to_zero}</b></p>
        <p><b>${tr("بعد نجاح التنفيذ: ميزان المراجعة = صفر، وأرصدة الخزائن = صفر.","After successful execution: trial balance = zero and treasury balances = zero.")}</b></p>
        <p class="muted">${tr("بيانات ستظل محفوظة:","Data that will be preserved:")} ${d.protected.map(esc).join("، ")}</p>
        <p class="muted">${tr("راجع القائمة جيدًا. لن يتم الحذف بمجرد المعاينة.","Review carefully. Preview alone never deletes data.")}</p>`;
      $("#confirmbox").hidden = false;
    } catch(e) { $("#reseterr").textContent = errText(e); }
    finally { busy(false); }
  }));
  $("#execute").onclick = async () => {
    if (!previewMode) { $("#reseterr").textContent = tr("أعد معاينة التصفير الشامل قبل التنفيذ.","Preview the complete reset before execution."); return; }
    if ($("#resetphrase").value !== "RESET") { $("#reseterr").textContent = tr("اكتب RESET كما هو.","Type RESET exactly."); return; }
    if (!$("#resetpassword").value) { $("#reseterr").textContent = tr("أدخل كلمة مرور المدير.","Enter the administrator password."); return; }
    const promptText = tr("تأكيد أخير: سيتم أخذ نسخة احتياطية ثم حذف البيانات الموضحة في المعاينة. هل تريد الاستمرار؟","Final confirmation: a backup will be created, then the previewed data will be deleted. Continue?");
    if (!confirm(promptText)) return;
    busy(true); $("#reseterr").textContent = "";
    try {
      const d = await api("/admin/reset/execute", {method:"POST", json:{mode:previewMode,confirm_text:$("#resetphrase").value,password:$("#resetpassword").value}});
      toast(d.message);
      $("#previewbox").innerHTML = `<p class="tag ok">${esc(d.message)}</p><p>${tr("النسخة الاحتياطية:","Backup:")} <b dir="ltr">${esc(d.backup)}</b></p><p>${tr("عدد السجلات المحذوفة:","Deleted rows:")} ${Object.values(d.deleted).reduce((a,b)=>a+b,0).toLocaleString()}</p>`;
      $("#confirmbox").hidden = true; previewMode = null;
    } catch(e) { $("#reseterr").textContent = errText(e); }
    finally { busy(false); }
  };
}
